package com.springgenie.spring_genie_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringGenieBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringGenieBackendApplication.class, args);
	}

}
